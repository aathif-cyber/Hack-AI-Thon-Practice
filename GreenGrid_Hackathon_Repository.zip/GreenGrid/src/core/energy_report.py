from collections import defaultdict
from .energy_record import EnergyRecord
from .recommendations import generate_recommendation

class EnergyReport:
    """Calculates totals, rankings and recommendations from energy records."""

    def __init__(self, records=None, tariff_per_kwh=8.0, emission_factor=0.708):
        self.records = list(records or [])
        self.tariff_per_kwh = float(tariff_per_kwh)
        self.emission_factor = float(emission_factor)

    @property
    def total_kwh(self) -> float:
        return sum(r.energy_kwh for r in self.records)

    @property
    def estimated_cost(self) -> float:
        return self.total_kwh * self.tariff_per_kwh

    @property
    def estimated_emissions_kg(self) -> float:
        return self.total_kwh * self.emission_factor

    def appliance_totals(self):
        totals = defaultdict(float)
        categories = {}
        for r in self.records:
            totals[r.appliance.name] += r.energy_kwh
            categories[r.appliance.name] = r.appliance.category
        return sorted(
            [(name, kwh, categories[name]) for name, kwh in totals.items()],
            key=lambda x: x[1],
            reverse=True
        )

    def top_consumers(self, limit=5):
        return self.appliance_totals()[:limit]

    def recommendations(self, limit=5):
        return [
            (name, generate_recommendation(name, category, kwh))
            for name, kwh, category in self.top_consumers(limit)
        ]

    def summary(self) -> dict:
        return {
            "total_kwh": round(self.total_kwh, 2),
            "estimated_cost": round(self.estimated_cost, 2),
            "estimated_emissions_kg": round(self.estimated_emissions_kg, 2),
            "top_consumers": self.top_consumers(),
            "recommendations": self.recommendations(),
        }
