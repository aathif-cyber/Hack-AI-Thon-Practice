"""GreenGrid application entry point."""
from gui.dashboard import GreenGridApp, load_records

if __name__ == "__main__":
    app = GreenGridApp(load_records())
    app.mainloop()
