from dataclasses import dataclass

@dataclass(frozen=True)
class Appliance:
    """Represents an electrical appliance and its rated power."""
    name: str
    power_watts: float
    category: str = "General"

    def __post_init__(self):
        if not self.name.strip():
            raise ValueError("Appliance name cannot be empty.")
        if self.power_watts <= 0:
            raise ValueError("Power rating must be greater than zero.")

    def energy_for_hours(self, hours: float) -> float:
        """Return energy consumption in kWh for the given usage hours."""
        if hours < 0:
            raise ValueError("Usage hours cannot be negative.")
        return (self.power_watts * hours) / 1000.0
