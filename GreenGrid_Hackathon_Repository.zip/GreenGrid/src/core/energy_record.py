from dataclasses import dataclass
from datetime import date
from .appliance import Appliance

@dataclass
class EnergyRecord:
    """A usage record for an appliance during a period."""
    appliance: Appliance
    usage_hours: float
    period: str
    record_date: date | None = None

    def __post_init__(self):
        if self.usage_hours < 0:
            raise ValueError("Usage hours cannot be negative.")
        if not self.period.strip():
            raise ValueError("Period cannot be empty.")
        if self.record_date is None:
            self.record_date = date.today()

    @property
    def energy_kwh(self) -> float:
        return self.appliance.energy_for_hours(self.usage_hours)
