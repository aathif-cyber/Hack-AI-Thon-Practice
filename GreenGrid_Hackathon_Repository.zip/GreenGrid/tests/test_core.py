import unittest
from src.core.appliance import Appliance
from src.core.energy_record import EnergyRecord
from src.core.energy_report import EnergyReport

class TestGreenGrid(unittest.TestCase):
    def setUp(self):
        ac = Appliance("Air Conditioner", 1500, "Cooling")
        fan = Appliance("Ceiling Fan", 70, "Cooling")
        self.records = [
            EnergyRecord(ac, 4, "Daily"),
            EnergyRecord(fan, 8, "Daily"),
        ]

    def test_energy_calculation(self):
        self.assertAlmostEqual(self.records[0].energy_kwh, 6.0)

    def test_report_totals(self):
        report = EnergyReport(self.records, tariff_per_kwh=8, emission_factor=0.7)
        self.assertAlmostEqual(report.total_kwh, 6.56)
        self.assertAlmostEqual(report.estimated_cost, 52.48)
        self.assertAlmostEqual(report.estimated_emissions_kg, 4.592)

    def test_ranking(self):
        report = EnergyReport(self.records)
        self.assertEqual(report.top_consumers()[0][0], "Air Conditioner")

if __name__ == "__main__":
    unittest.main()
