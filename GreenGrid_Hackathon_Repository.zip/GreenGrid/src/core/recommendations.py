def generate_recommendation(name: str, category: str, energy_kwh: float) -> str:
    """Generate a simple, explainable recommendation from appliance usage."""
    n = name.lower()
    c = category.lower()

    if "air conditioner" in n or "ac" == n.strip():
        return "Set the AC to an efficient temperature and reduce unnecessary runtime."
    if "heater" in n:
        return "Lower the heater temperature and switch it off when the space is comfortable."
    if "refrigerator" in n or "fridge" in n:
        return "Keep the refrigerator door closed and maintain efficient cooling settings."
    if "light" in c or "led" in n:
        return "Switch off unused lights and prefer LED lighting."
    if "fan" in n:
        return "Use the fan at the lowest comfortable speed and switch it off in empty rooms."
    if "washing" in n:
        return "Prefer full-load washes and efficient cycles."
    if "television" in n or "tv" in n:
        return "Avoid standby mode and switch the TV off completely when not in use."
    if energy_kwh >= 50:
        return "High consumption detected: reduce runtime and review the appliance's power rating."
    return "Monitor usage and switch the appliance off when it is not needed."
