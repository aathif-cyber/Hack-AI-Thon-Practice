# 🌱 GreenGrid — Smart Energy Consumption & Carbon Tracker

> **Turn electricity data into clear actions for lower cost, lower consumption, and lower carbon impact.**

[![Python](https://img.shields.io/badge/Python-3.10%2B-blue?logo=python)](https://www.python.org/)
[![OOP](https://img.shields.io/badge/Design-OOP-green)]
[![SDG 7](https://img.shields.io/badge/SDG-7-yellow)]
[![SDG 11](https://img.shields.io/badge/SDG-11-orange)]
[![SDG 13](https://img.shields.io/badge/SDG-13-red)]

## 🏆 Hack-AI-Thon 2026

**Theme:** Python Fundamentals + Object-Oriented Programming (OOP) + Sustainable Development Goals (SDGs)

**Project:** GreenGrid – Smart Energy Consumption & Carbon Tracker

GreenGrid is a Python-based energy-management application that records electricity usage for appliances, rooms, homes, or institutions and converts raw usage data into understandable energy, cost, and carbon insights.

The application:
- records appliance name, power rating, usage hours and date/period;
- calculates estimated energy consumption in kWh;
- estimates electricity cost using a configurable tariff;
- estimates carbon emissions using a configurable emission factor;
- ranks the highest-consuming appliances;
- generates practical energy-saving recommendations;
- presents the results through an attractive desktop dashboard.

The challenge requires a functional prototype, meaningful sample/test data, and a primarily Python/OOP implementation. The required classes are `Appliance`, `EnergyRecord`, and `EnergyReport`. 

## ✨ Why GreenGrid?

Many people see an electricity bill, but cannot easily answer:
1. Which appliance is consuming the most?
2. How much energy does it actually use?
3. What is the estimated cost of that usage?
4. What is the associated carbon impact?
5. What action should be taken first?

**GreenGrid answers all five in one place.**

## 🎯 Core Objectives

- Make energy consumption understandable.
- Convert appliance usage into measurable kWh, cost and emissions.
- Highlight energy hotspots.
- Recommend realistic actions.
- Demonstrate clean Python fundamentals and OOP.
- Connect software engineering with SDG-focused sustainability.

## 🌍 SDG Alignment

| SDG | Connection |
|---|---|
| **SDG 7 — Affordable & Clean Energy** | Helps users understand and reduce unnecessary electricity consumption. |
| **SDG 11 — Sustainable Cities & Communities** | Supports more energy-aware homes and institutions. |
| **SDG 13 — Climate Action** | Makes carbon impact visible and encourages lower-emission choices. |

## 🧠 Calculation Logic

### Energy
`Energy (kWh) = Power (W) × Usage Hours ÷ 1000`

### Cost
`Estimated Cost = Energy (kWh) × Tariff per kWh`

### Carbon
`Estimated Emissions (kg CO₂e) = Energy (kWh) × Emission Factor`

All factors are configurable in the application.

## 🏗️ Architecture

```text
                    ┌──────────────────────┐
                    │      GreenGrid GUI   │
                    │   Tkinter Dashboard  │
                    └──────────┬───────────┘
                               │
                               ▼
                    ┌──────────────────────┐
                    │    EnergyReport      │
                    │ totals / ranking /   │
                    │ recommendations      │
                    └──────────┬───────────┘
                               │
                  ┌────────────┴────────────┐
                  ▼                         ▼
        ┌──────────────────┐      ┌──────────────────┐
        │   EnergyRecord   │      │     Appliance    │
        │ usage/date/data  │      │ power/profile    │
        └──────────────────┘      └──────────────────┘
```

## 📁 Repository Structure

```text
GreenGrid/
├── README.md
├── requirements.txt
├── LICENSE
├── .gitignore
├── src/
│   ├── main.py
│   ├── core/
│   │   ├── appliance.py
│   │   ├── energy_record.py
│   │   ├── energy_report.py
│   │   └── recommendations.py
│   ├── gui/
│   │   └── dashboard.py
│   └── data/
│       └── sample_data.json
├── tests/
│   └── test_core.py
├── docs/
│   ├── FULL_REPORT.md
│   ├── FUTURE_SCOPE.md
│   ├── SYSTEM_DESIGN.md
│   ├── TESTING.md
│   └── images/
│       ├── dashboard.png
│       └── report.png
├── presentation/
│   └── GreenGrid_Presentation.pptx
└── video/
    └── PUT_YOUR_DEMO_VIDEO_HERE.txt
```

## 🚀 Run the Project

### Requirements
- Python **3.10+**
- Tkinter (normally included with Python on Windows/macOS; on some Linux distributions install the Tk package)
- No third-party Python packages are required for the application.

### Windows
```bash
python src/main.py
```

### Run tests
```bash
python -m unittest discover -s tests -v
```

## 🎬 Demo Flow

For a strong judging demo:

1. Launch GreenGrid.
2. Show the live dashboard and KPI cards.
3. Add or review appliance usage.
4. Change tariff/emission factor.
5. Generate the energy report.
6. Point out the highest-consuming appliance.
7. Show recommendations.
8. Explain how OOP classes drive the calculation.
9. Close with SDG impact and future scope.

## 🧪 Sample Scenario

The included sample dataset contains appliances such as:
- Air Conditioner
- Refrigerator
- Television
- Ceiling Fan
- LED Lights
- Washing Machine

The values are representative demo data and can be replaced with real measurements.

## 🔐 Design Principles

- **Encapsulation:** each class owns its relevant data and behavior.
- **Abstraction:** the report layer hides calculation details from the GUI.
- **Modularity:** core logic is separated from presentation.
- **Configurability:** tariff and emission factor can be changed without changing the calculation code.
- **Testability:** core calculations are covered by unit tests.

## 📌 Limitations

GreenGrid provides **estimates**, not utility-grade meter readings. Accuracy depends on the supplied power ratings, usage hours, tariff and emission factor.

## 🔮 Future Scope

- Smart-meter/IoT integration
- Automatic electricity-bill import
- Appliance-level real-time monitoring
- Monthly trend analytics
- User accounts and cloud dashboards
- Machine-learning based consumption forecasting
- Personalized carbon-reduction targets
- Mobile/web version
- Regional tariff and grid-emission databases

## 👥 Authors

**Aathif · Paras · Vetri · Sanket**

---

### ⭐ Hackathon Pitch

> **“GreenGrid does not just tell users how much electricity they used — it tells them where the energy went, what it cost, what it emitted, and what they can do next.”**
