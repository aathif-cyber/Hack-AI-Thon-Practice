# 2–3 Minute Winning Demo Script

**0:00–0:15 — Hook**

“An electricity bill tells us how much we paid. GreenGrid tells us why we paid it.”

**0:15–0:40 — Problem + Solution**

“GreenGrid records appliance power and usage and turns it into energy, cost and carbon insights.”

**0:40–1:20 — Live Dashboard**

Show the four KPI cards. Explain the top consumer table. Point to the AC as the largest energy hotspot.

**1:20–1:45 — Configurability**

Change the tariff and click Recalculate. Show the cost changing. Explain that the emission factor is also configurable.

**1:45–2:05 — OOP**

“Appliance represents the device, EnergyRecord represents usage, and EnergyReport performs aggregation, ranking and recommendations.”

**2:05–2:25 — Sustainability**

“This connects directly to SDG 7, SDG 11 and SDG 13 by making energy waste and carbon impact visible.”

**2:25–2:45 — Future**

“Next, GreenGrid can connect smart meters and IoT devices, forecast consumption and detect unusual energy spikes.”

**Closing**

“GreenGrid does not just tell users how much electricity they used — it tells them where the energy went, what it cost, what it emitted, and what they can do next.”
