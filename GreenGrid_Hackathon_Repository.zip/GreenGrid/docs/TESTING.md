# Testing Strategy

## Unit Tests
Run:

```bash
python -m unittest discover -s tests -v
```

The current tests cover:
- appliance energy calculation;
- report totals;
- cost calculation;
- carbon calculation;
- consumer ranking.

## Manual GUI Test Checklist

| Test | Expected |
|---|---|
| Launch application | Dashboard opens |
| View KPI cards | Energy, cost, carbon and appliance count appear |
| Change tariff | Estimated cost updates |
| Change emission factor | Carbon estimate updates |
| View ranking | Highest consumer appears first |
| View recommendations | Advice cards appear |
| Invalid tariff | Validation message appears |

## Demo Data
The included JSON data is representative sample data for demonstrating the prototype.
