# GreenGrid — System Design

## 1. Input Layer
The user supplies appliance name, power rating, usage hours and period/date. Tariff and emission factor are configurable.

## 2. Domain Layer
- `Appliance`: validates appliance identity and power rating.
- `EnergyRecord`: represents a usage event and exposes energy in kWh.
- `EnergyReport`: aggregates records and produces totals, ranking and recommendations.

## 3. Presentation Layer
A Tkinter dashboard displays KPI cards, ranked energy consumers and recommendations.

## 4. OOP Concepts Demonstrated

### Encapsulation
Data and operations are grouped into domain classes.

### Abstraction
The GUI calls `EnergyReport` rather than implementing formulas itself.

### Composition
`EnergyRecord` contains an `Appliance` object.

### Reusability
The report engine can be reused by another interface, such as a web or mobile front end.

## 5. Data Flow

```text
User / Sample JSON
      ↓
Appliance
      ↓
EnergyRecord
      ↓
EnergyReport
  ↙    ↓     ↘
kWh   Cost   Carbon
      ↓
Ranking + Recommendations
      ↓
Dashboard
```
