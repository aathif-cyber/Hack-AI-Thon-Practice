import json
import tkinter as tk
from tkinter import ttk, messagebox

from core.appliance import Appliance
from core.energy_record import EnergyRecord
from core.energy_report import EnergyReport

BG = "#F4F7FB"
NAVY = "#16324F"
GREEN = "#19A974"
TEAL = "#0EA5A4"
BLUE = "#3B82F6"
ORANGE = "#F59E0B"
RED = "#EF4444"
TEXT = "#172033"
MUTED = "#64748B"
WHITE = "#FFFFFF"

class GreenGridApp(tk.Tk):
    def __init__(self, records):
        super().__init__()
        self.title("GreenGrid — Smart Energy Dashboard")
        self.geometry("1180x760")
        self.minsize(1000, 680)
        self.configure(bg=BG)
        self.records = records
        self.tariff = 8.0
        self.emission_factor = 0.708
        self._setup_style()
        self._build_ui()
        self.refresh()

    def _setup_style(self):
        style = ttk.Style(self)
        style.theme_use("clam")
        style.configure("Treeview", rowheight=34, font=("Segoe UI", 10),
                        background=WHITE, fieldbackground=WHITE, foreground=TEXT)
        style.configure("Treeview.Heading", font=("Segoe UI Semibold", 10),
                        background="#E8EEF6", foreground=NAVY, relief="flat")
        style.map("Treeview", background=[("selected", "#DDEAFE")],
                  foreground=[("selected", NAVY)])

    def _label(self, parent, text, size=11, bold=False, color=TEXT):
        return tk.Label(parent, text=text, font=("Segoe UI", size, "bold" if bold else "normal"),
                        bg=parent.cget("bg"), fg=color)

    def _build_ui(self):
        header = tk.Frame(self, bg=NAVY, height=82)
        header.pack(fill="x")
        header.pack_propagate(False)
        tk.Label(header, text="🌱  GreenGrid", font=("Segoe UI", 24, "bold"),
                 bg=NAVY, fg=WHITE).pack(side="left", padx=28, pady=18)
        tk.Label(header, text="Smart Energy • Cost • Carbon", font=("Segoe UI", 11),
                 bg=NAVY, fg="#C9D8E8").pack(side="right", padx=30)

        body = tk.Frame(self, bg=BG)
        body.pack(fill="both", expand=True, padx=24, pady=20)

        title = tk.Frame(body, bg=BG)
        title.pack(fill="x")
        self._label(title, "Energy Overview", 20, True, NAVY).pack(side="left")
        self._label(title, "Understand where your energy goes.", 10, False, MUTED).pack(side="left", padx=14, pady=8)

        controls = tk.Frame(body, bg=BG)
        controls.pack(fill="x", pady=(15, 12))
        self._label(controls, "Tariff ₹/kWh", 9, True, MUTED).pack(side="left")
        self.tariff_var = tk.StringVar(value="8.0")
        tk.Entry(controls, textvariable=self.tariff_var, width=8, font=("Segoe UI", 10),
                 relief="flat", bg=WHITE).pack(side="left", padx=(7, 18), ipady=6)
        self._label(controls, "CO₂ kg/kWh", 9, True, MUTED).pack(side="left")
        self.factor_var = tk.StringVar(value="0.708")
        tk.Entry(controls, textvariable=self.factor_var, width=8, font=("Segoe UI", 10),
                 relief="flat", bg=WHITE).pack(side="left", padx=(7, 18), ipady=6)
        tk.Button(controls, text="↻  Recalculate", command=self.refresh, bg=GREEN, fg=WHITE,
                  activebackground=GREEN, relief="flat", font=("Segoe UI", 10, "bold"),
                  padx=15, pady=7, cursor="hand2").pack(side="left")

        self.cards = tk.Frame(body, bg=BG)
        self.cards.pack(fill="x")
        self.kpi = {}
        self._card("ENERGY", "0 kWh", TEAL)
        self._card("EST. COST", "₹0", GREEN)
        self._card("CARBON", "0 kg CO₂e", ORANGE)
        self._card("APPLIANCES", "0", BLUE)

        content = tk.Frame(body, bg=BG)
        content.pack(fill="both", expand=True, pady=(18, 0))

        left = tk.Frame(content, bg=WHITE, highlightthickness=1, highlightbackground="#E2E8F0")
        left.pack(side="left", fill="both", expand=True, padx=(0, 10))
        self._label(left, "Top Energy Consumers", 13, True, NAVY).pack(anchor="w", padx=18, pady=(16, 10))
        self.tree = ttk.Treeview(left, columns=("rank","name","kwh","share"), show="headings")
        for col, heading, width in [("rank","#",45),("name","Appliance",190),("kwh","kWh",90),("share","Share",90)]:
            self.tree.heading(col, text=heading)
            self.tree.column(col, width=width, anchor="center" if col!="name" else "w")
        self.tree.pack(fill="both", expand=True, padx=15, pady=(0, 15))

        right = tk.Frame(content, bg=WHITE, highlightthickness=1, highlightbackground="#E2E8F0", width=410)
        right.pack(side="right", fill="y")
        right.pack_propagate(False)
        self._label(right, "💡 Smart Recommendations", 13, True, NAVY).pack(anchor="w", padx=18, pady=(16, 10))
        self.rec_frame = tk.Frame(right, bg=WHITE)
        self.rec_frame.pack(fill="both", expand=True, padx=18)

        footer = tk.Label(self, text="GreenGrid • Python + OOP • SDG 7 • SDG 11 • SDG 13",
                          bg="#E8EEF6", fg=MUTED, font=("Segoe UI", 9))
        footer.pack(fill="x", ipady=8)

    def _card(self, key, value, accent):
        f = tk.Frame(self.cards, bg=WHITE, highlightthickness=1, highlightbackground="#E2E8F0")
        f.pack(side="left", fill="x", expand=True, padx=(0, 10))
        bar = tk.Frame(f, bg=accent, width=6)
        bar.pack(side="left", fill="y")
        inner = tk.Frame(f, bg=WHITE)
        inner.pack(fill="both", expand=True, padx=15, pady=12)
        tk.Label(inner, text=key, bg=WHITE, fg=MUTED, font=("Segoe UI", 8, "bold")).pack(anchor="w")
        v = tk.Label(inner, text=value, bg=WHITE, fg=TEXT, font=("Segoe UI", 19, "bold"))
        v.pack(anchor="w", pady=(4,0))
        self.kpi[key] = v

    def refresh(self):
        try:
            self.tariff = float(self.tariff_var.get())
            self.emission_factor = float(self.factor_var.get())
            if self.tariff < 0 or self.emission_factor < 0:
                raise ValueError
        except ValueError:
            messagebox.showerror("Invalid settings", "Tariff and emission factor must be non-negative numbers.")
            return

        report = EnergyReport(self.records, self.tariff, self.emission_factor)
        self.kpi["ENERGY"].config(text=f"{report.total_kwh:.1f} kWh")
        self.kpi["EST. COST"].config(text=f"₹{report.estimated_cost:,.0f}")
        self.kpi["CARBON"].config(text=f"{report.estimated_emissions_kg:.1f} kg")
        self.kpi["APPLIANCES"].config(text=str(len(report.appliance_totals())))

        for item in self.tree.get_children():
            self.tree.delete(item)
        for i, (name, kwh, _) in enumerate(report.top_consumers(), 1):
            share = (kwh / report.total_kwh * 100) if report.total_kwh else 0
            self.tree.insert("", "end", values=(i, name, f"{kwh:.1f}", f"{share:.1f}%"))

        for w in self.rec_frame.winfo_children():
            w.destroy()
        for name, text in report.recommendations(4):
            box = tk.Frame(self.rec_frame, bg="#F8FAFC", highlightthickness=1,
                           highlightbackground="#E2E8F0")
            box.pack(fill="x", pady=5)
            tk.Label(box, text=name, bg="#F8FAFC", fg=TEAL,
                     font=("Segoe UI", 10, "bold")).pack(anchor="w", padx=12, pady=(9,2))
            tk.Label(box, text=text, bg="#F8FAFC", fg=TEXT, justify="left",
                     wraplength=340, font=("Segoe UI", 9)).pack(anchor="w", padx=12, pady=(0,9))

def load_records():
    with open("src/data/sample_data.json", encoding="utf-8") as f:
        data = json.load(f)
    records = []
    for item in data["records"]:
        appliance = Appliance(item["name"], item["power_watts"], item["category"])
        records.append(EnergyRecord(appliance, item["hours"], item["period"]))
    return records

if __name__ == "__main__":
    app = GreenGridApp(load_records())
    app.mainloop()
