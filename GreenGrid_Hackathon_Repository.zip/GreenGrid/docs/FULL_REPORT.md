# GreenGrid — Full Project Report

## Abstract
GreenGrid is a Python-based smart energy consumption and carbon tracking prototype. It transforms appliance usage information into estimated electricity consumption, cost, carbon emissions, energy rankings and actionable recommendations.

## 1. Problem Statement
People and institutions often know their total electricity bill but lack a simple way to identify the appliances responsible for the largest share of consumption. The challenge asks for an energy-management application that records appliance usage and estimates energy, cost and carbon impact using configurable factors.

## 2. Proposed Solution
GreenGrid provides a lightweight desktop dashboard backed by a modular Python/OOP calculation engine. Users can inspect energy KPIs, see top-consuming appliances and receive explainable recommendations.

## 3. Objectives
1. Record appliance usage.
2. Calculate kWh.
3. Estimate cost.
4. Estimate carbon emissions.
5. Rank energy-consuming appliances.
6. Provide saving recommendations.
7. Demonstrate Python fundamentals and OOP.
8. Align software output with sustainability goals.

## 4. SDG Mapping
### SDG 7 — Affordable and Clean Energy
Energy visibility encourages responsible electricity usage.

### SDG 11 — Sustainable Cities and Communities
Energy-aware buildings and institutions can use consumption insights to improve resource efficiency.

### SDG 13 — Climate Action
Showing estimated CO₂ impact makes the climate consequence of energy use easier to understand.

## 5. Functional Requirements
- Appliance registration/representation.
- Energy record creation.
- kWh calculation.
- Cost calculation.
- Carbon calculation.
- Top-consumer ranking.
- Recommendation generation.
- Dashboard reporting.

## 6. Non-Functional Requirements
- Easy to understand.
- Modular code.
- Explainable calculations.
- Fast local execution.
- No mandatory external API.
- Testable core logic.

## 7. Technology Stack
- Python 3.10+
- Tkinter
- `dataclasses`
- `json`
- `unittest`

The application intentionally uses standard-library modules to keep the prototype portable.

## 8. Algorithm
For each record:
1. Read appliance power in watts.
2. Read usage hours.
3. Calculate kWh = watts × hours / 1000.
4. Add the kWh to the total.
5. Multiply total kWh by tariff for cost.
6. Multiply total kWh by emission factor for estimated CO₂e.
7. Aggregate kWh by appliance.
8. Sort appliances in descending order.
9. Generate recommendations for the largest consumers.

## 9. User Interface
The dashboard uses:
- dark navy header;
- clean white cards;
- green sustainability accents;
- KPI summaries;
- ranked consumer table;
- recommendation cards;
- configurable calculation factors.

## 10. OOP Implementation
`Appliance`, `EnergyRecord`, and `EnergyReport` form the core object model. The GUI depends on the report layer instead of duplicating business logic.

## 11. Testing
Unit tests validate:
- energy formula;
- total energy;
- cost;
- emissions;
- ranking order.

## 12. Limitations
Results depend on user-entered ratings, hours, tariff and emission factor. Real-world appliance behavior can vary from rated power.

## 13. Future Scope
### Phase 1
- Add/edit/delete records.
- Monthly charts.
- CSV import/export.
- PDF reports.

### Phase 2
- Smart-meter integration.
- IoT sensor data.
- Automatic bill parsing.
- User accounts.

### Phase 3
- Forecasting.
- Anomaly detection.
- Personalized targets.
- Cloud dashboard.
- Mobile application.

## 14. Expected Impact
GreenGrid aims to make energy consumption visible and actionable. Its main value is not only reporting a number, but connecting that number to a specific appliance and a practical next step.

## 15. Conclusion
GreenGrid demonstrates how a compact Python/OOP system can connect software engineering with sustainability. It satisfies the requested reporting workflow while leaving a clear path toward real-time monitoring and intelligent energy optimization.
